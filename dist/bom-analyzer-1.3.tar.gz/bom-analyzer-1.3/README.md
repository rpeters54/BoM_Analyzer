# BoM-Analyzer Python Package

Using unsupervised machine learning to find anomalies in a Cisco Bill of Materials.